import React, { useState } from 'react';
import { TicketData, Agent, AnalysisResult, User } from './types';
import { MOCK_TICKETS, MOCK_AGENTS, EMPTY_TICKET } from './constants';
import TicketInput from './components/TicketInput';
import AgentList from './components/AgentList';
import AnalysisDisplay from './components/AnalysisDisplay';
import LoginPage from './components/LoginPage';
import TicketDashboard from './components/TicketDashboard';
import { analyzeTicketWithGemini } from './services/geminiService';
import { 
  LayoutGrid, 
  Ticket, 
  Users, 
  BarChart2, 
  Settings, 
  Search, 
  Bell, 
  HelpCircle,
  Hexagon,
  MessageSquare,
  Cpu,
  ArrowLeft,
  LogOut
} from 'lucide-react';

const App: React.FC = () => {
  // Auth State
  const [user, setUser] = useState<User | null>(null);

  // Application State
  const [view, setView] = useState<'dashboard' | 'ticket'>('dashboard');
  const [tickets, setTickets] = useState<TicketData[]>(Object.values(MOCK_TICKETS));
  const [ticket, setTicket] = useState<TicketData>(EMPTY_TICKET);
  const [agents, setAgents] = useState<Agent[]>(MOCK_AGENTS);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'conversation' | 'properties'>('conversation');
  const [isEditing, setIsEditing] = useState(false);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setView('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setView('dashboard');
    setTicket(EMPTY_TICKET);
    setAnalysisResult(null);
  };

  const handleCreateNewTicket = () => {
    const newId = `TICK-${Math.floor(1000 + Math.random() * 9000)}`;
    setTicket({ ...EMPTY_TICKET, ticket_id: newId, created_at: new Date().toISOString() });
    setAnalysisResult(null);
    setIsEditing(true); // Allow editing for new tickets
    setActiveTab('conversation');
    setView('ticket');
  };

  const handleSelectTicket = (selectedTicket: TicketData) => {
    setTicket(selectedTicket);
    // Restore saved analysis if available
    setAnalysisResult(selectedTicket.analysis || null); 
    
    // Logic: If ticket is closed, it's read only. If it's open, we default to view only unless explicitly editing?
    // Prompt says: "when i am entering into customer who have already submitted thier ticket the converstion page must be i viewing mode"
    // So we set isEditing to false.
    setIsEditing(false); 

    setActiveTab('conversation');
    setView('ticket');
  };

  const saveTicket = (ticketToSave: TicketData) => {
    setTickets(prev => {
        const index = prev.findIndex(t => t.ticket_id === ticketToSave.ticket_id);
        if (index >= 0) {
            const newTickets = [...prev];
            newTickets[index] = ticketToSave;
            return newTickets;
        } else {
            return [ticketToSave, ...prev];
        }
    });
  };

  // Called when user explicitly saves the analysis from the Properties tab
  const handleSaveAnalysis = () => {
    const updatedTicket: TicketData = {
        ...ticket,
        status: 'closed', // Mark as closed
        analysis: analysisResult || undefined
    };
    setTicket(updatedTicket);
    saveTicket(updatedTicket);
    setIsEditing(false); // Ensure read-only mode is active
    alert("Ticket analysis saved and ticket marked as Closed.");
  };

  const handleAnalyze = async () => {
    setIsLoading(true);
    try {
      const result = await analyzeTicketWithGemini(ticket, agents);
      setAnalysisResult(result);
      
      // We don't save to the main list yet, we wait for user confirmation via "Save Analysis & Close"
      // But we update current ticket state so the UI reflects it
      const updatedTicket = { ...ticket, analysis: result };
      setTicket(updatedTicket);
      
      setActiveTab('properties'); // Auto-switch to properties view
    } catch (err) {
      console.error(err);
      alert("Analysis failed. Please check your configuration.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleTicketChange = (updatedTicket: TicketData) => {
      setTicket(updatedTicket);
  };

  const bestAgent = analysisResult
    ? agents.find(a => a.agent_id === analysisResult.best_agent.agent_id)
    : undefined;

  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-[#f8f9fa] font-sans text-slate-800 overflow-hidden">
      
      {/* 1. Dark Vertical Sidebar */}
      <aside className="w-[60px] bg-[#03363d] flex flex-col items-center py-4 gap-6 shrink-0 z-50">
        <div className="text-[#a5babc] hover:text-white cursor-pointer transition-colors">
            <Hexagon className="w-8 h-8 fill-current text-white" />
        </div>
        
        <nav className="flex flex-col gap-1 w-full px-2">
            <SidebarItem 
                icon={<LayoutGrid size={20} />} 
                label="Dashboard" 
                active={view === 'dashboard'} 
                onClick={() => setView('dashboard')}
            />
            <SidebarItem 
                icon={<Ticket size={20} />} 
                label="Active Ticket" 
                active={view === 'ticket'} 
                onClick={() => view === 'ticket' ? null : handleCreateNewTicket()}
            />
            <SidebarItem icon={<Users size={20} />} label="Customers" />
            <SidebarItem icon={<BarChart2 size={20} />} label="Reporting" />
        </nav>

        <div className="mt-auto flex flex-col gap-4 w-full px-2 mb-4">
             <SidebarItem icon={<Settings size={20} />} label="Settings" />
             
             {/* Profile / Logout */}
             <div className="relative group flex justify-center">
                <div 
                    className="w-8 h-8 rounded-full bg-indigo-500 text-white flex items-center justify-center font-bold text-xs cursor-pointer ring-2 ring-[#03363d] ring-offset-2 ring-offset-[#03363d]"
                    title={user.name}
                >
                    {user.name.charAt(0)}
                </div>
                
                {/* Custom Logout Tooltip Button */}
                <div 
                    onClick={handleLogout}
                    className="absolute left-10 bottom-0 ml-2 bg-white text-slate-700 px-3 py-1.5 rounded shadow-lg border border-slate-200 text-xs font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2 cursor-pointer z-50 pointer-events-none group-hover:pointer-events-auto hover:bg-slate-50"
                >
                    <LogOut size={12} />
                    Log Out
                </div>
             </div>
        </div>
      </aside>

      {/* 2. Main Content Wrapper */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Top Header */}
        <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-4 shrink-0 shadow-[0_1px_2px_rgba(0,0,0,0.03)] z-40">
           <div className="flex items-center gap-3">
              {view === 'ticket' && (
                  <button 
                    onClick={() => setView('dashboard')}
                    className="mr-2 p-1.5 hover:bg-slate-100 rounded-full text-slate-500 transition-colors"
                    title="Back to Dashboard"
                  >
                      <ArrowLeft size={18} />
                  </button>
              )}
              <div className="flex items-center text-sm text-slate-500">
                 <span 
                    className="hover:underline cursor-pointer"
                    onClick={() => setView('dashboard')}
                 >
                    Tickets
                 </span>
                 {view === 'ticket' && (
                     <>
                        <span className="mx-2">/</span>
                        <span className="font-semibold text-slate-800 truncate max-w-[200px]">{ticket.ticket_id}</span>
                     </>
                 )}
              </div>
              
              {view === 'ticket' && (
                <div className="flex gap-2">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                        ticket.customer_priority_tier === 'enterprise' ? 'bg-purple-50 text-purple-700 border-purple-200' : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}>
                        {ticket.customer_priority_tier.toUpperCase()}
                    </span>
                    {ticket.status === 'closed' && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded border bg-slate-100 text-slate-500 border-slate-200 flex items-center gap-1">
                            CLOSED
                        </span>
                    )}
                </div>
              )}
           </div>

           <div className="flex items-center gap-4">
              <div className="relative hidden md:block">
                 <Search className="absolute left-2.5 top-1.5 w-4 h-4 text-slate-400" />
                 <input 
                    type="text" 
                    placeholder="Search..." 
                    className="pl-9 pr-4 py-1.5 text-sm bg-slate-100 border-transparent rounded hover:bg-slate-200 focus:bg-white focus:border-indigo-500 transition-all w-64 outline-none"
                 />
              </div>
              <div className="flex items-center gap-3 text-slate-400">
                  <HelpCircle className="w-5 h-5 hover:text-slate-600 cursor-pointer" />
                  <Bell className="w-5 h-5 hover:text-slate-600 cursor-pointer" />
              </div>
           </div>
        </header>

        {/* View Switcher */}
        {view === 'dashboard' ? (
            <TicketDashboard 
                tickets={tickets} 
                onCreateNew={handleCreateNewTicket}
                onSelectTicket={handleSelectTicket}
            />
        ) : (
            <>
                {/* Tab Navigation (Only in Ticket View) */}
                <div className="h-12 bg-white border-b border-slate-200 flex items-end px-6 gap-6 shrink-0">
                    <button 
                        onClick={() => setActiveTab('conversation')}
                        className={`pb-3 text-sm font-medium transition-all relative ${
                            activeTab === 'conversation' 
                            ? 'text-[#03363d] border-b-2 border-[#03363d]' 
                            : 'text-slate-500 hover:text-slate-700'
                        }`}
                    >
                        <div className="flex items-center gap-2">
                            <MessageSquare size={16} />
                            Conversation
                        </div>
                    </button>
                    <button 
                        onClick={() => setActiveTab('properties')}
                        className={`pb-3 text-sm font-medium transition-all relative ${
                            activeTab === 'properties' 
                            ? 'text-[#03363d] border-b-2 border-[#03363d]' 
                            : 'text-slate-500 hover:text-slate-700'
                        }`}
                    >
                        <div className="flex items-center gap-2">
                            <Cpu size={16} />
                            AI Analysis & Properties
                            {analysisResult && <span className="w-2 h-2 rounded-full bg-emerald-500 absolute -right-2 top-0"></span>}
                        </div>
                    </button>
                </div>

                {/* Main Stage Content */}
                <main className="flex-1 overflow-hidden relative bg-slate-50">
                
                {/* VIEW 1: CONVERSATION */}
                {activeTab === 'conversation' && (
                    <div className="h-full w-full max-w-5xl mx-auto shadow-sm border-x border-slate-200 bg-white">
                        <TicketInput 
                                ticket={ticket} 
                                onChange={handleTicketChange} 
                                onAnalyze={handleAnalyze}
                                isLoading={isLoading}
                                // ReadOnly if not in editing mode OR if ticket is closed
                                readOnly={!isEditing || ticket.status === 'closed'}
                        />
                    </div>
                )}

                {/* VIEW 2: PROPERTIES / ANALYSIS */}
                {activeTab === 'properties' && (
                    <div className="h-full overflow-y-auto p-8">
                        <div className="max-w-6xl mx-auto grid grid-cols-12 gap-8">
                            
                            {/* Left Column: Analysis Results */}
                            <div className="col-span-12 lg:col-span-8 space-y-6">
                                <div className="bg-white rounded border border-slate-200 shadow-sm p-6">
                                    <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
                                        <Cpu className="text-indigo-600" /> 
                                        Intelligent Routing Analysis
                                    </h3>
                                    <AnalysisDisplay 
                                        result={analysisResult} 
                                        agent={bestAgent}
                                        onSave={handleSaveAnalysis}
                                        isSaved={ticket.status === 'closed'}
                                    />
                                </div>
                            </div>

                            {/* Right Column: Agent Availability */}
                            <div className="col-span-12 lg:col-span-4 space-y-6">
                                <div className="bg-white rounded border border-slate-200 shadow-sm p-6">
                                    <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-4">
                                        Agent Availability
                                    </h3>
                                    <AgentList agents={agents} bestAgentId={bestAgent?.agent_id} />
                                </div>

                                    {/* Additional Widget Mockup */}
                                <div className="bg-white rounded border border-slate-200 shadow-sm p-6">
                                    <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-4">
                                        Similar Tickets
                                    </h3>
                                    <div className="space-y-3">
                                        <div className="text-sm text-indigo-600 hover:underline cursor-pointer truncate">
                                            #{Math.floor(Math.random() * 1000)} Payment failure on checkout
                                        </div>
                                        <div className="text-sm text-indigo-600 hover:underline cursor-pointer truncate">
                                            #{Math.floor(Math.random() * 1000)} 500 Error on API gateway
                                        </div>
                                        <div className="text-sm text-indigo-600 hover:underline cursor-pointer truncate">
                                            #{Math.floor(Math.random() * 1000)} Latency in US-East region
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                </main>
            </>
        )}
      </div>
    </div>
  );
};

// Helper Component for Sidebar
const SidebarItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }> = ({ icon, label, active, onClick }) => (
    <div 
        onClick={onClick}
        className={`
            w-10 h-10 rounded-lg flex items-center justify-center cursor-pointer transition-all duration-200 group relative
            ${active ? 'bg-black/20 text-white shadow-inner' : 'text-[#a5babc] hover:bg-black/10 hover:text-white'}
        `}
        title={label}
    >
        {icon}
    </div>
);

export default App;