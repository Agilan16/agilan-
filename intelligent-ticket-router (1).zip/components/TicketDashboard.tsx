import React from 'react';
import { TicketData } from '../types';
import { Plus, Search, Filter, AlertCircle, Calendar } from 'lucide-react';

interface TicketDashboardProps {
  tickets: TicketData[];
  onCreateNew: () => void;
  onSelectTicket: (ticket: TicketData) => void;
}

const TicketDashboard: React.FC<TicketDashboardProps> = ({ tickets, onCreateNew, onSelectTicket }) => {
  return (
    <div className="flex-1 bg-slate-50 p-8 overflow-y-auto h-full">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Support Dashboard</h1>
            <p className="text-slate-500 mt-1">Manage and track your support requests</p>
          </div>
          <button
            onClick={onCreateNew}
            className="bg-[#03363d] hover:bg-[#022a30] text-white px-5 py-2.5 rounded-lg flex items-center gap-2 font-medium shadow-sm transition-all hover:shadow-md"
          >
            <Plus size={18} />
            New Ticket
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
                <div className="text-slate-500 text-sm font-medium mb-1">Open Tickets</div>
                <div className="text-3xl font-bold text-slate-800">{tickets.length}</div>
            </div>
            <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
                <div className="text-slate-500 text-sm font-medium mb-1">Avg Resolution</div>
                <div className="text-3xl font-bold text-slate-800">4.2h</div>
            </div>
            <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
                <div className="text-slate-500 text-sm font-medium mb-1">Critical Issues</div>
                <div className="text-3xl font-bold text-rose-600">
                    {tickets.filter(t => t.customer_priority_tier === 'enterprise' || t.urgency_indicators.caps > 5).length}
                </div>
            </div>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
          {/* Toolbar */}
          <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search tickets..."
                className="pl-9 pr-4 py-2 border border-slate-300 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-[#03363d] focus:border-[#03363d] w-64 bg-white"
              />
            </div>
            <div className="flex items-center gap-2">
                <button className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:bg-slate-100 rounded-md border border-slate-300 bg-white text-sm font-medium transition-colors">
                    <Filter size={16} />
                    Filter
                </button>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-200">
                <tr>
                    <th className="px-6 py-4 w-32 font-semibold">Ticket ID</th>
                    <th className="px-6 py-4 font-semibold">Subject</th>
                    <th className="px-6 py-4 w-32 font-semibold">Priority</th>
                    <th className="px-6 py-4 w-32 font-semibold">Channel</th>
                    <th className="px-6 py-4 w-40 font-semibold">Created</th>
                </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                {tickets.length === 0 ? (
                    <tr>
                        <td colSpan={5} className="px-6 py-16 text-center text-slate-500">
                            <div className="flex flex-col items-center gap-2">
                                <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mb-2">
                                    <Plus className="text-slate-400" />
                                </div>
                                <p className="font-medium text-slate-600">No tickets yet</p>
                                <p className="text-sm text-slate-400">Create your first ticket to get started</p>
                            </div>
                        </td>
                    </tr>
                ) : (
                    tickets.map((ticket) => {
                        const isCritical = ticket.customer_priority_tier === 'enterprise' || ticket.urgency_indicators.caps > 5;
                        return (
                            <tr
                                key={ticket.ticket_id}
                                onClick={() => onSelectTicket(ticket)}
                                className="hover:bg-indigo-50/30 cursor-pointer transition-colors group"
                            >
                            <td className="px-6 py-4 font-mono text-xs text-slate-500 group-hover:text-indigo-600 font-medium">
                                {ticket.ticket_id}
                            </td>
                            <td className="px-6 py-4">
                                <div className="font-medium text-slate-800 group-hover:text-[#03363d] transition-colors">{ticket.subject || "Untitled Ticket"}</div>
                                <div className="text-xs text-slate-400 truncate max-w-md mt-0.5">{ticket.body.substring(0, 60)}...</div>
                            </td>
                            <td className="px-6 py-4">
                                {isCritical ? (
                                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 text-xs font-bold border border-rose-100">
                                        <AlertCircle size={12} /> Critical
                                    </span>
                                ) : (
                                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-medium border border-slate-200">
                                        Normal
                                    </span>
                                )}
                            </td>
                            <td className="px-6 py-4">
                                <span className="capitalize px-2 py-1 bg-white border border-slate-200 rounded text-xs text-slate-600">
                                    {ticket.channel}
                                </span>
                            </td>
                            <td className="px-6 py-4 text-slate-500">
                                <div className="flex items-center gap-2">
                                    <Calendar size={14} className="text-slate-400"/>
                                    {new Date(ticket.created_at).toLocaleDateString()}
                                </div>
                            </td>
                            </tr>
                        );
                    })
                )}
                </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TicketDashboard;