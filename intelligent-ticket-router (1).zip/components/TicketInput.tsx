import React, { useRef, useState } from 'react';
import { TicketData } from '../types';
import { MOCK_TICKETS } from '../constants';
import { generateTicketTitle, summarizeFileContent } from '../services/geminiService';
import { RefreshCw, Paperclip, MoreHorizontal, User, Zap, MessageSquare, Smile, Lock, Sparkles, Loader2, AlertCircle } from 'lucide-react';

interface TicketInputProps {
  ticket: TicketData;
  onChange: (ticket: TicketData) => void;
  onAnalyze: () => void;
  isLoading: boolean;
  readOnly?: boolean;
}

const EMOJIS = ['😊', '👍', '👎', '⚠️', '🔥', '🐛', '💳', '🔒', '📉', '👋'];

// Advanced keyword list for urgency detection
const URGENT_KEYWORDS = [
  'urgent', 'asap', 'immediately', 'critical', 'fail', 'error', 'broken', 'down', 'crash', 
  'outage', 'emergency', 'losing money', 'blocked', 'cannot', 'stopped', 'violation', 'security'
];

const TicketInput: React.FC<TicketInputProps> = ({ ticket, onChange, onAnalyze, isLoading, readOnly = false }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isGeneratingTitle, setIsGeneratingTitle] = useState(false);
  const [isAnalyzingFile, setIsAnalyzingFile] = useState(false);

  const calculateUrgency = (text: string) => {
    const lowerText = text.toLowerCase();
    
    // 1. Keyword analysis
    const foundKeywords = URGENT_KEYWORDS.filter(word => lowerText.includes(word));
    
    // 2. Caps analysis
    const capsCount = (text.match(/[A-Z]/g) || []).length;
    
    // 3. Exclamation analysis
    const exclaimCount = (text.match(/!/g) || []).length;
    
    // 4. Repetition analysis (detecting repeated phrases like "help help" or "please please")
    const words = lowerText.split(/\s+/);
    for (let i = 0; i < words.length - 1; i++) {
        if (words[i].length > 3 && words[i] === words[i+1]) {
            if (!foundKeywords.includes('repetition')) {
                foundKeywords.push('repetitive pleading');
            }
        }
    }

    return {
        caps: capsCount,
        exclaim_marks: exclaimCount,
        words: [...new Set(foundKeywords)] // Deduplicate
    };
  };

  const loadPreset = (preset: 'critical' | 'standard') => {
    if (readOnly) return;
    onChange(MOCK_TICKETS[preset]);
  };

  const handleChange = (field: keyof TicketData, value: any) => {
    if (readOnly) return;
    
    let updates: Partial<TicketData> = { [field]: value };

    // Real-time urgency calculation when body changes
    if (field === 'body') {
        const urgencyStats = calculateUrgency(value as string);
        updates.urgency_indicators = urgencyStats;
    }

    onChange({ ...ticket, ...updates });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (readOnly) return;
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      
      reader.onload = async (event) => {
        const text = event.target?.result as string;
        
        setIsAnalyzingFile(true);
        try {
            // Call Gemini to analyze the file content and generate a problem description
            const analysis = await summarizeFileContent(text);
            
            // We use the internal handleChange to ensure urgency is also calculated
            handleChange('body', analysis);
            
            // Optionally set a default subject if it's empty
            if (ticket.subject === "" || ticket.subject === "New Ticket") {
               handleChange('subject', `Issue detected in ${file.name}`);
            }
        } catch (error) {
            console.error("File analysis failed", error);
            // Fallback: just dump the text
            handleChange('body', text);
        } finally {
            setIsAnalyzingFile(false);
            // Reset file input so same file can be selected again if needed
            if (fileInputRef.current) fileInputRef.current.value = "";
        }
      };
      
      reader.readAsText(file);
    }
  };

  const handleAutoGenerateTitle = async () => {
    if (readOnly || !ticket.body) return;
    setIsGeneratingTitle(true);
    try {
        const generatedTitle = await generateTicketTitle(ticket.body);
        if (generatedTitle) {
            handleChange('subject', generatedTitle);
        }
    } catch (error) {
        console.error("Failed to generate title", error);
    } finally {
        setIsGeneratingTitle(false);
    }
  };

  const insertText = (textToInsert: string) => {
    if (readOnly) return;
    if (textareaRef.current) {
        const start = textareaRef.current.selectionStart;
        const end = textareaRef.current.selectionEnd;
        const currentText = ticket.body;
        const newText = currentText.substring(0, start) + textToInsert + currentText.substring(end);
        handleChange('body', newText);
        
        setTimeout(() => {
            textareaRef.current?.focus();
            textareaRef.current?.setSelectionRange(start + textToInsert.length, start + textToInsert.length);
        }, 0);
    } else {
        handleChange('body', ticket.body + textToInsert);
    }
  };

  const handleToggleChannel = () => {
    if (readOnly) return;
    const newChannel = ticket.channel === 'chat' ? 'email' : 'chat';
    handleChange('channel', newChannel);
    if (newChannel === 'chat' && !ticket.body.trim()) {
        handleChange('body', "[System]: Chat started.\n[Customer]: ");
    }
  };

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* Ticket Header Area */}
      <div className="px-8 py-6 border-b border-slate-100">
        <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles size={12} /> Intelligent Summary of Customer Issue
            </span>
            {/* Real-time urgency indicator badge */}
            {!readOnly && ticket.urgency_indicators.words.length > 0 && (
                <span className="text-[10px] font-bold text-rose-600 bg-rose-50 border border-rose-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <AlertCircle size={10} />
                    High Urgency Detected
                </span>
            )}
        </div>
        <div className="flex items-center gap-3">
            <input
                type="text"
                readOnly={readOnly}
                className={`flex-1 text-2xl font-bold text-slate-800 placeholder-slate-300 border-none focus:ring-0 p-0 bg-transparent ${readOnly ? 'cursor-default' : ''}`}
                placeholder="Add subject..."
                value={ticket.subject}
                onChange={(e) => handleChange('subject', e.target.value)}
            />
            {!readOnly && ticket.body.length > 10 && (
                <button
                    onClick={handleAutoGenerateTitle}
                    disabled={isGeneratingTitle}
                    className="group flex items-center gap-2 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold transition-all border border-indigo-100"
                    title="Intelligent Summary of Customer Issue"
                >
                    {isGeneratingTitle ? (
                        <Loader2 size={14} className="animate-spin" />
                    ) : (
                        <Sparkles size={14} className="group-hover:fill-indigo-300" />
                    )}
                    {isGeneratingTitle ? 'Generating...' : 'Auto Title'}
                </button>
            )}
        </div>
        
        <div className="flex items-center gap-4 mt-2">
            <div className="flex items-center gap-2 text-sm text-slate-500">
                <span className="font-semibold text-slate-700">Requester:</span>
                <span className="flex items-center gap-1"><User size={14}/> {ticket.customer_id}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-500">
                <span className="font-semibold text-slate-700">Created:</span>
                <span>{new Date(ticket.created_at).toLocaleDateString()}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-500">
                <span className="font-semibold text-slate-700">Via:</span>
                <span className={`capitalize px-2 py-0.5 rounded text-xs font-medium transition-colors ${ticket.channel === 'chat' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600'}`}>
                    {ticket.channel}
                </span>
            </div>
            {readOnly && (
                <div className="ml-auto flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-500 text-xs font-bold border border-slate-200">
                    <Lock size={12} />
                    READ ONLY
                </div>
            )}
        </div>
      </div>

      {/* Conversation Stream */}
      <div className="flex-1 p-8 bg-white overflow-y-auto">
        
        {/* The Incoming Message Bubble */}
        <div className="flex gap-4 mb-8">
            <div className="w-10 h-10 rounded-full bg-amber-100 border border-amber-200 flex items-center justify-center text-amber-700 font-bold shrink-0">
                {ticket.customer_id.substring(0, 2)}
            </div>
            <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-slate-800">Customer {ticket.customer_id}</span>
                    <span className="text-xs text-slate-400">{new Date(ticket.created_at).toLocaleString()}</span>
                </div>
                <div className={`bg-slate-50 border border-slate-200 rounded-lg rounded-tl-none p-5 text-slate-700 leading-relaxed text-sm focus-within:ring-1 focus-within:ring-indigo-500 transition-all ${ticket.channel === 'chat' ? 'font-mono text-xs' : ''}`}>
                     {readOnly ? (
                        <div className="whitespace-pre-wrap">{ticket.body}</div>
                     ) : (
                         <div className="relative w-full">
                            {isAnalyzingFile && (
                                <div className="absolute inset-0 z-10 bg-slate-50/80 backdrop-blur-sm flex items-center justify-center">
                                    <div className="flex items-center gap-2 text-indigo-600 text-sm font-semibold">
                                        <Loader2 className="animate-spin w-4 h-4" />
                                        Analyzing file content...
                                    </div>
                                </div>
                            )}
                            <textarea 
                                ref={textareaRef}
                                className="w-full bg-transparent border-none focus:ring-0 p-0 text-slate-700 resize-none h-auto min-h-[150px]"
                                value={ticket.body}
                                onChange={(e) => handleChange('body', e.target.value)}
                                placeholder={ticket.channel === 'chat' ? "Paste chat transcript here...\n[Customer]: Hi, I need help.\n[Agent]: Sure..." : "Describe the issue..."}
                            />
                         </div>
                     )}
                </div>
            </div>
        </div>

        {/* Divider */}
        <div className="relative flex py-5 items-center">
            <div className="flex-grow border-t border-slate-200"></div>
            <span className="flex-shrink-0 mx-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">System Analysis</span>
            <div className="flex-grow border-t border-slate-200"></div>
        </div>

        {/* Action Bar / Simulation Controls */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-1 relative">
            {/* Emoji Picker Popup */}
            {showEmojiPicker && !readOnly && (
                <div className="absolute bottom-full left-32 mb-2 bg-white border border-slate-200 shadow-xl rounded-lg p-2 grid grid-cols-5 gap-1 w-40 z-20">
                    {EMOJIS.map(emoji => (
                        <button 
                            key={emoji}
                            className="p-1.5 hover:bg-slate-100 rounded text-lg transition-colors"
                            onClick={() => {
                                insertText(emoji);
                                setShowEmojiPicker(false);
                            }}
                        >
                            {emoji}
                        </button>
                    ))}
                    <button 
                        className="col-span-5 text-xs text-slate-400 hover:text-slate-600 p-1 border-t border-slate-100 mt-1"
                        onClick={() => setShowEmojiPicker(false)}
                    >
                        Close
                    </button>
                </div>
            )}

            {!readOnly && (
                <div className="flex items-center gap-2 px-3 py-2 border-b border-slate-200/60 mb-2">
                    <button className="text-xs font-bold text-slate-600 hover:text-slate-800 px-2 py-1 rounded hover:bg-slate-200 transition-colors">Public Reply</button>
                    <button className="text-xs font-bold text-slate-600 hover:text-slate-800 px-2 py-1 rounded hover:bg-slate-200 transition-colors">Internal Note</button>
                    <div className="ml-auto flex gap-2">
                        <button onClick={() => loadPreset('standard')} className="text-[10px] px-2 py-0.5 bg-white border border-slate-300 rounded hover:bg-slate-100 transition-colors">Load Standard</button>
                        <button onClick={() => loadPreset('critical')} className="text-[10px] px-2 py-0.5 bg-white border border-slate-300 rounded hover:bg-slate-100 transition-colors">Load Critical</button>
                    </div>
                </div>
            )}
            
            <div className="px-4 pb-2">
                 <div className="flex items-center justify-between text-slate-400 text-sm">
                    {readOnly ? (
                        <div className="text-xs text-slate-500 italic flex items-center gap-2">
                             <User size={14} /> Ticket is closed. Conversation is read-only.
                        </div>
                    ) : (
                        <div className="flex items-center gap-4">
                            {/* Attach File */}
                            <div 
                                className={`flex items-center gap-1.5 cursor-pointer transition-colors ${isAnalyzingFile ? 'text-indigo-500' : 'hover:text-slate-600'}`}
                                onClick={() => !isAnalyzingFile && fileInputRef.current?.click()}
                                title="Attach File"
                            >
                                {isAnalyzingFile ? <Loader2 size={16} className="animate-spin" /> : <Paperclip size={16} />}
                                <span className="text-xs font-medium">{isAnalyzingFile ? 'Analyzing...' : 'Attach'}</span>
                                <input 
                                    type="file" 
                                    ref={fileInputRef} 
                                    className="hidden" 
                                    onChange={handleFileUpload}
                                />
                            </div>

                            {/* Separator */}
                            <div className="h-4 w-[1px] bg-slate-300"></div>

                            {/* Chat Section Controls */}
                            <div 
                                className={`flex items-center gap-1.5 cursor-pointer transition-colors select-none ${ticket.channel === 'chat' ? 'text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded' : 'hover:text-slate-600'}`}
                                onClick={handleToggleChannel}
                                title={ticket.channel === 'chat' ? 'Switch to Email' : 'Switch to Chat'}
                            >
                                <MessageSquare size={16} />
                                <span className="text-xs font-medium">{ticket.channel === 'chat' ? 'Chat Mode' : 'Chat'}</span>
                            </div>

                            <div 
                                className={`flex items-center gap-1.5 cursor-pointer transition-colors select-none ${showEmojiPicker ? 'text-amber-500' : 'hover:text-slate-600'}`}
                                title="Insert Emoji"
                                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                            >
                                <Smile size={16} />
                            </div>
                            
                            <MoreHorizontal size={16} className="cursor-pointer hover:text-slate-600 ml-1" />
                        </div>
                    )}
                    
                    {!readOnly && (
                        <button
                            onClick={onAnalyze}
                            disabled={isLoading}
                            className={`flex items-center gap-2 px-4 py-2 rounded text-sm font-medium text-white transition-all ml-auto ${
                                isLoading 
                                ? 'bg-slate-400 cursor-not-allowed' 
                                : 'bg-[#1f73b7] hover:bg-[#144a75] shadow-sm'
                            }`}
                        >
                            {isLoading ? <RefreshCw className="animate-spin w-4 h-4" /> : <Zap className="w-4 h-4" />}
                            {isLoading ? 'Processing...' : 'Run Analysis'}
                        </button>
                    )}
                 </div>
            </div>
        </div>
        
      </div>
    </div>
  );
};

export default TicketInput;