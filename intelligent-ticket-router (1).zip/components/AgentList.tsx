import React from 'react';
import { Agent } from '../types';

interface AgentListProps {
  agents: Agent[];
  bestAgentId?: string;
}

const AgentList: React.FC<AgentListProps> = ({ agents, bestAgentId }) => {
  return (
    <div className="space-y-2">
        {agents.map((agent) => {
          const isSelected = agent.agent_id === bestAgentId;
          const workloadPercentage = (agent.current_workload / agent.capacity) * 100;

          return (
            <div
              key={agent.agent_id}
              className={`flex items-center gap-3 p-2 rounded border ${
                isSelected
                  ? 'bg-indigo-50 border-indigo-200 ring-1 ring-indigo-200'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              } transition-all`}
            >
               {/* Avatar */}
               <div className={`w-8 h-8 rounded flex items-center justify-center text-xs font-bold shrink-0 ${
                   isSelected ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-500'
               }`}>
                  {agent.name.charAt(0)}
               </div>

               {/* Info */}
               <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                      <span className="text-xs font-semibold text-slate-700 truncate">{agent.name}</span>
                      {isSelected && <span className="text-[10px] font-bold text-indigo-600">BEST</span>}
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                     {/* Capacity Bar */}
                     <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div 
                            className={`h-full rounded-full ${workloadPercentage > 80 ? 'bg-red-400' : 'bg-emerald-400'}`}
                            style={{ width: `${workloadPercentage}%` }}
                        ></div>
                     </div>
                     <span className="text-[10px] text-slate-400 w-8 text-right">{agent.current_workload}/{agent.capacity}</span>
                  </div>
               </div>
            </div>
          );
        })}
    </div>
  );
};

export default AgentList;