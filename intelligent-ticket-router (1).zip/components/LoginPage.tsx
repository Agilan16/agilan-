import React, { useState } from 'react';
import { User, Lock, Mail, ArrowRight, Hexagon } from 'lucide-react';
import { User as UserType } from '../types';

interface LoginPageProps {
  onLogin: (user: UserType) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email) {
      onLogin({ name, email });
    }
  };

  return (
    <div className="min-h-screen bg-[#f8f9fa] flex flex-col justify-center items-center p-4 font-sans text-slate-800">
      <div className="bg-white p-10 rounded shadow-lg border border-slate-200 max-w-[400px] w-full">
        <div className="flex justify-center mb-8">
           <div className="text-[#03363d] flex items-center gap-2">
              <Hexagon className="w-8 h-8 fill-current" />
              <span className="text-2xl font-bold tracking-tight">Support<span className="font-light">Desk</span> AI</span>
           </div>
        </div>

        <h2 className="text-center text-lg font-medium text-slate-700 mb-6">Sign in to your account</h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="text"
                required
                className="block w-full pl-10 pr-3 py-2.5 bg-white border border-slate-300 rounded hover:border-slate-400 focus:border-[#03363d] focus:ring-1 focus:ring-[#03363d] outline-none transition-all text-sm"
                placeholder="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
          </div>

          <div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="email"
                required
                className="block w-full pl-10 pr-3 py-2.5 bg-white border border-slate-300 rounded hover:border-slate-400 focus:border-[#03363d] focus:ring-1 focus:ring-[#03363d] outline-none transition-all text-sm"
                placeholder="Work Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 bg-[#03363d] hover:bg-[#022a30] text-white font-medium py-2.5 px-4 rounded transition-all mt-4 text-sm"
          >
            Sign In
          </button>
        </form>
      </div>
      <div className="mt-8 text-center text-xs text-slate-400">
        &copy; {new Date().getFullYear()} Intelligent Routing Systems
      </div>
    </div>
  );
};

export default LoginPage;