import React from 'react';
import { AnalysisResult, Agent } from '../types';
import { AlertCircle, Clock, BarChart3, Tag, UserCheck, Sparkles, AlertTriangle, Save, CheckCircle } from 'lucide-react';

interface AnalysisDisplayProps {
  result: AnalysisResult | null;
  agent: Agent | undefined;
  onSave?: () => void;
  isSaved?: boolean;
}

const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({ result, agent, onSave, isSaved }) => {
  if (!result) {
    return (
      <div className="p-6 text-center border-2 border-dashed border-slate-200 rounded-lg bg-slate-50/50">
        <Sparkles className="w-8 h-8 text-slate-300 mx-auto mb-2" />
        <p className="text-sm text-slate-500">Run analysis to see routing predictions</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* AI Reasoning Box */}
      <div className="bg-indigo-50 border border-indigo-100 rounded p-3">
          <div className="flex items-start gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-indigo-600 mt-0.5" />
              <h4 className="text-xs font-bold text-indigo-900 uppercase">AI Reasoning</h4>
          </div>
          <p className="text-xs text-indigo-800 leading-relaxed">
              {result.explanation}
          </p>
      </div>

      {/* Field: Priority */}
      <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-500">Priority</label>
          <div className="flex items-center gap-2">
            <div className={`flex-1 flex items-center gap-2 px-3 py-2 rounded border text-sm font-medium ${
                result.priority_label === 'P1' ? 'bg-red-50 border-red-200 text-red-700' :
                result.priority_label === 'P2' ? 'bg-orange-50 border-orange-200 text-orange-700' :
                'bg-blue-50 border-blue-200 text-blue-700'
            }`}>
                {result.priority_label === 'P1' && <AlertTriangle size={14} />}
                {result.priority_label} - {result.priority_label === 'P1' ? 'Urgent' : result.priority_label === 'P2' ? 'High' : 'Normal'}
            </div>
            <div className="text-xs text-slate-400 font-mono bg-white border border-slate-200 px-1.5 py-2 rounded" title="Priority Score">
                {result.priority_score}
            </div>
          </div>
      </div>

      {/* Field: Category */}
      <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-500">Routing Category</label>
          <div className="w-full px-3 py-2 bg-white border border-slate-300 rounded text-sm text-slate-700 capitalize flex items-center gap-2">
              <Tag size={14} className="text-slate-400" />
              {result.route_category}
          </div>
      </div>

       {/* Field: Effort */}
       <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-500">Effort Estimation</label>
          <div className="grid grid-cols-2 gap-2">
            <div className="px-3 py-2 bg-white border border-slate-300 rounded text-sm text-slate-700 flex items-center gap-2">
                <Clock size={14} className="text-slate-400" />
                {result.predicted_resolution_hours}h
            </div>
            <div className="px-3 py-2 bg-white border border-slate-300 rounded text-sm text-slate-700 capitalize flex items-center justify-center">
                {result.effort_level}
            </div>
          </div>
      </div>

      {/* Field: Assignee */}
      <div className="space-y-1 pt-4 border-t border-slate-200">
          <label className="text-xs font-semibold text-slate-500">Recommended Assignee</label>
          {agent ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded p-3 group hover:border-emerald-300 transition-colors cursor-pointer">
                  <div className="flex items-center gap-3 mb-2">
                      <div className="w-8 h-8 rounded bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                          {agent.name.charAt(0)}
                      </div>
                      <div>
                          <div className="text-sm font-bold text-slate-800">{agent.name}</div>
                          <div className="text-[10px] text-slate-500">{agent.agent_id} • Match Score: 98%</div>
                      </div>
                      <UserCheck className="w-4 h-4 text-emerald-600 ml-auto" />
                  </div>
                  <p className="text-[10px] text-emerald-800 leading-snug">
                      {result.best_agent.reason}
                  </p>
              </div>
          ) : (
            <div className="px-3 py-2 bg-slate-100 border border-slate-200 rounded text-sm text-slate-400 italic">
                Pending analysis...
            </div>
          )}
      </div>

      {/* Save Action */}
      <div className="pt-6 mt-4 border-t border-slate-200">
          {isSaved ? (
              <div className="w-full bg-slate-100 text-slate-500 font-medium py-3 rounded flex items-center justify-center gap-2 cursor-not-allowed border border-slate-200">
                  <CheckCircle size={18} className="text-slate-400" />
                  Analysis Saved & Ticket Closed
              </div>
          ) : (
             onSave && (
                <button 
                    onClick={onSave}
                    className="w-full bg-[#03363d] hover:bg-[#022a30] text-white font-medium py-3 rounded shadow-sm flex items-center justify-center gap-2 transition-all"
                >
                    <Save size={18} />
                    Save Analysis & Close Ticket
                </button>
             )
          )}
      </div>

    </div>
  );
};

export default AnalysisDisplay;