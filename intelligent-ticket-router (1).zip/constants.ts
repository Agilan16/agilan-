import { Agent } from './types';

export const SYSTEM_INSTRUCTION = `
You are an advanced AI model designed to build and improve an INTELLIGENT TICKET ROUTING SYSTEM.

Your job is to analyze support tickets end-to-end and produce:
1. Correct routing category
2. Priority classification + priority score
3. Predicted resolution time (in hours)
4. Estimated effort (low, medium, high)
5. Best agent to assign to
6. A clear explanation of the reasoning

### INPUT YOU WILL RECEIVE
You will be given a JSON object containing a "ticket" object and an "agents" array.

### YOUR OUTPUT FORMAT (ALWAYS STRICT JSON)
Your output must ALWAYS follow this exact format:
{
 "route_category": "billing",
 "priority_label": "P1",
 "priority_score": 85,
 "predicted_resolution_hours": 4.5,
 "effort_level": "medium",
 "best_agent": {
   "agent_id": "A1",
   "reason": "Agent has matching skills and low workload."
 },
 "explanation": "Ticket involves critical billing failure. Assigned to A1 due to billing expertise."
}

### HOW TO DECIDE EACH FIELD
1. Routing Category: Use product area, keywords, API words, UI words.
2. Priority Label: P1 (high urgency, bad sentiment), P2 (moderate), P3 (calm).
   Priority Score: Weighted combination of sentiment, urgency, caps, SLA, customer tier. Range 0-100.
3. Predicted Resolution Hours: Based on complexity (billing 6h, api 10h, auth 4h, ui 8h, delivery 24h), sentiment, tier.
4. Effort Level: low (<6h), medium (6-20h), high (>20h).
5. Best Agent: Highest skill match, lowest workload, available capacity, timezone.

### STYLE RULES
- Output must be clean JSON only.
- No markdown.
- Be deterministic.
`;

export const MOCK_AGENTS: Agent[] = [
  {
    agent_id: "A1",
    name: "Sarah Chen",
    skills: ["billing", "api", "finance"],
    expertise_score: { "billing": 0.95, "api": 0.7, "finance": 0.8 },
    avg_resolution_hours: 6.2,
    capacity: 8,
    current_workload: 3,
    timezone: "Asia/Kolkata",
    last_active: "2023-10-27T09:00:00Z"
  },
  {
    agent_id: "A2",
    name: "Mike Ross",
    skills: ["ui", "delivery", "frontend"],
    expertise_score: { "ui": 0.9, "delivery": 0.6, "frontend": 0.85 },
    avg_resolution_hours: 4.5,
    capacity: 5,
    current_workload: 4,
    timezone: "America/New_York",
    last_active: "2023-10-27T14:00:00Z"
  },
  {
    agent_id: "A3",
    name: "Jessica Pearson",
    skills: ["auth", "security", "api"],
    expertise_score: { "auth": 0.98, "security": 0.95, "api": 0.7 },
    avg_resolution_hours: 8.0,
    capacity: 6,
    current_workload: 1,
    timezone: "Europe/London",
    last_active: "2023-10-27T10:30:00Z"
  },
  {
    agent_id: "A4",
    name: "David Kim",
    skills: ["database", "performance", "backend"],
    expertise_score: { "database": 0.95, "performance": 0.9, "backend": 0.8 },
    avg_resolution_hours: 5.5,
    capacity: 7,
    current_workload: 2,
    timezone: "America/Los_Angeles",
    last_active: "2023-10-27T16:00:00Z"
  },
  {
    agent_id: "A5",
    name: "Maria Garcia",
    skills: ["mobile", "ui", "ios", "android"],
    expertise_score: { "mobile": 0.95, "ui": 0.8, "ios": 0.9 },
    avg_resolution_hours: 4.0,
    capacity: 6,
    current_workload: 3,
    timezone: "Europe/Madrid",
    last_active: "2023-10-27T09:15:00Z"
  },
  {
    agent_id: "A6",
    name: "Robert Zane",
    skills: ["devops", "cloud", "security"],
    expertise_score: { "devops": 0.95, "cloud": 0.9, "security": 0.8 },
    avg_resolution_hours: 3.5,
    capacity: 5,
    current_workload: 0,
    timezone: "America/New_York",
    last_active: "2023-10-27T13:45:00Z"
  },
  {
    agent_id: "A7",
    name: "Rachel Zane",
    skills: ["general", "compliance", "legal"],
    expertise_score: { "general": 0.9, "compliance": 0.85, "legal": 0.8 },
    avg_resolution_hours: 5.0,
    capacity: 6,
    current_workload: 2,
    timezone: "America/New_York",
    last_active: "2023-10-27T11:00:00Z"
  },
  {
    agent_id: "A8",
    name: "Louis Litt",
    skills: ["finance", "billing", "compliance"],
    expertise_score: { "finance": 0.99, "billing": 0.95, "compliance": 0.9 },
    avg_resolution_hours: 7.5,
    capacity: 4,
    current_workload: 1,
    timezone: "America/New_York",
    last_active: "2023-10-27T08:30:00Z"
  },
  {
    agent_id: "A9",
    name: "Donna Paulsen",
    skills: ["triage", "general", "vip"],
    expertise_score: { "triage": 1.0, "general": 0.95, "vip": 0.9 },
    avg_resolution_hours: 2.0,
    capacity: 10,
    current_workload: 5,
    timezone: "America/New_York",
    last_active: "2023-10-27T09:00:00Z"
  },
  {
    agent_id: "A10",
    name: "Harvey Specter",
    skills: ["strategy", "enterprise", "critical"],
    expertise_score: { "strategy": 1.0, "enterprise": 0.95, "critical": 0.9 },
    avg_resolution_hours: 12.0,
    capacity: 3,
    current_workload: 2,
    timezone: "America/New_York",
    last_active: "2023-10-27T10:00:00Z"
  }
];

export const MOCK_TICKETS: Record<string, any> = {
  standard: {
    ticket_id: "TICK-1001",
    subject: "Login page is loading slowly",
    body: "I'm trying to log in to my dashboard but the page takes about 20 seconds to load. This started happening this morning.",
    created_at: new Date().toISOString(),
    channel: 'email',
    attachments: 0,
    customer_id: "CUST-402",
    customer_priority_tier: 'silver',
    past_tickets_count_30d: 2,
    past_avg_resolution_hours: 24,
    sla_hours: 48,
    escalation_count: 0,
    sentiment_score: 0.6,
    urgency_indicators: { caps: 0, exclaim_marks: 0, words: [] },
    product_area: 'auth',
    language: 'en',
    status: 'open'
  },
  critical: {
    ticket_id: "TICK-9999",
    subject: "BILLING API IS DOWN - CANNOT PROCESS PAYMENTS",
    body: "URGENT: All our payment requests are failing with 503 errors. We are losing money every minute!! FIX THIS NOW.",
    created_at: new Date().toISOString(),
    channel: 'chat',
    attachments: 2,
    customer_id: "CUST-ENTERPRISE-01",
    customer_priority_tier: 'enterprise',
    past_tickets_count_30d: 12,
    past_avg_resolution_hours: 2,
    sla_hours: 1,
    escalation_count: 1,
    sentiment_score: 0.1,
    urgency_indicators: { caps: 15, exclaim_marks: 5, words: ['urgent', 'fail', 'losing money'] },
    product_area: 'billing',
    language: 'en',
    status: 'open'
  }
};

export const EMPTY_TICKET: any = {
  ticket_id: "",
  subject: "",
  body: "",
  created_at: new Date().toISOString(),
  channel: 'email',
  attachments: 0,
  customer_id: "GUEST",
  customer_priority_tier: 'free',
  past_tickets_count_30d: 0,
  past_avg_resolution_hours: 0,
  sla_hours: 72,
  escalation_count: 0,
  sentiment_score: 0.5,
  urgency_indicators: { caps: 0, exclaim_marks: 0, words: [] },
  product_area: 'other',
  language: 'en',
  status: 'open'
};