import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Agent, TicketData, AnalysisResult } from "../types";
import { SYSTEM_INSTRUCTION } from "../constants";

export const generateTicketTitle = async (ticketBody: string): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please set process.env.API_KEY.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate a concise, objective, and professional subject line (maximum 10 words) that serves as an "Intelligent Summary of Customer Issue" for the following support ticket body. Do not use quotes or prefixes like "Subject:".
      
      Ticket Body:
      ${ticketBody.substring(0, 5000)}`,
    });

    return response.text ? response.text.trim() : "";
  } catch (error) {
    console.error("Gemini Title Generation Failed:", error);
    return "";
  }
};

export const summarizeFileContent = async (fileContent: string): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please set process.env.API_KEY.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `You are a technical support assistant. A user has uploaded a file (logs, code snippet, or error report) to open a support ticket. 
      
      Analyze the file content below and write a clear, first-person description of the problem to populate the ticket body. 
      - Describe the errors found.
      - Mention specific error codes or failure points if present in the text.
      - Keep it under 200 words.
      - Do not include greetings like "Dear Support". Start directly with the problem description.

      File Content:
      ${fileContent.substring(0, 10000)}`,
    });

    return response.text ? response.text.trim() : fileContent.substring(0, 500);
  } catch (error) {
    console.error("Gemini File Analysis Failed:", error);
    return fileContent; // Fallback to raw content if AI fails
  }
};

export const analyzeTicketWithGemini = async (
  ticket: TicketData,
  agents: Agent[]
): Promise<AnalysisResult> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please set process.env.API_KEY.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // Construct a clear text prompt with the JSON data
  const prompt = `Analyze the following ticket and available agents to determine routing, priority, and resolution details.

Ticket Data:
${JSON.stringify(ticket, null, 2)}

Available Agents:
${JSON.stringify(agents, null, 2)}
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        // Schema definition with descriptions to guide the model
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            route_category: {
              type: Type.STRING,
              description: "The category of the ticket (e.g., billing, auth, api, ui, delivery, generic)"
            },
            priority_label: {
              type: Type.STRING,
              enum: ["P1", "P2", "P3"],
              description: "Priority level: P1 (Critical), P2 (High), P3 (Normal)"
            },
            priority_score: {
              type: Type.NUMBER,
              description: "A score from 0 to 100 indicating priority"
            },
            predicted_resolution_hours: {
              type: Type.NUMBER,
              description: "Estimated hours to resolve the ticket"
            },
            effort_level: {
              type: Type.STRING,
              enum: ["low", "medium", "high"],
              description: "Estimated effort level based on resolution hours"
            },
            best_agent: {
              type: Type.OBJECT,
              properties: {
                agent_id: { type: Type.STRING, description: "ID of the best suitable agent" },
                reason: { type: Type.STRING, description: "Reason for selecting this agent" },
              },
              required: ["agent_id", "reason"],
            },
            explanation: {
              type: Type.STRING,
              description: "A brief explanation of the analysis and routing decision"
            },
          },
          required: [
            "route_category",
            "priority_label",
            "priority_score",
            "predicted_resolution_hours",
            "effort_level",
            "best_agent",
            "explanation",
          ],
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response from Gemini.");
    }

    // Sanitize the output to ensure valid JSON (remove markdown code blocks if present)
    const cleanText = text.replace(/```json/g, "").replace(/```/g, "").trim();

    return JSON.parse(cleanText) as AnalysisResult;
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    throw error;
  }
};