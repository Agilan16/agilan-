export interface TicketData {
  ticket_id: string;
  subject: string;
  body: string;
  created_at: string;
  channel: 'email' | 'chat' | 'phone' | 'social';
  attachments: number;
  customer_id: string;
  customer_priority_tier: 'free' | 'silver' | 'gold' | 'enterprise';
  past_tickets_count_30d: number;
  past_avg_resolution_hours: number;
  sla_hours: number;
  escalation_count: number;
  sentiment_score: number;
  urgency_indicators: {
    caps: number;
    exclaim_marks: number;
    words: string[];
  };
  product_area: 'billing' | 'auth' | 'api' | 'ui' | 'delivery' | 'other';
  language: string;
  status: 'open' | 'closed';
  analysis?: AnalysisResult;
}

export interface Agent {
  agent_id: string;
  name: string;
  skills: string[];
  expertise_score: Record<string, number>;
  avg_resolution_hours: number;
  capacity: number;
  current_workload: number;
  timezone: string;
  last_active: string;
}

export interface AnalysisResult {
  route_category: string;
  priority_label: 'P1' | 'P2' | 'P3';
  priority_score: number;
  predicted_resolution_hours: number;
  effort_level: 'low' | 'medium' | 'high';
  best_agent: {
    agent_id: string;
    reason: string;
  };
  explanation: string;
}

export interface User {
  name: string;
  email: string;
}